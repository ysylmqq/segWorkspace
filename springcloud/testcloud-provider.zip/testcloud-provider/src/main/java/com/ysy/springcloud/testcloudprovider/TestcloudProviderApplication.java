package com.ysy.springcloud.testcloudprovider;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestcloudProviderApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestcloudProviderApplication.class, args);
	}
}
