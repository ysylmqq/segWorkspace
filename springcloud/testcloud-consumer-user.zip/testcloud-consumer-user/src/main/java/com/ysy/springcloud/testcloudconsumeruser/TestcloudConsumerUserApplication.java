package com.ysy.springcloud.testcloudconsumeruser;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestcloudConsumerUserApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestcloudConsumerUserApplication.class, args);
	}
}
