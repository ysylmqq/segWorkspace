package com.ysy.springcloud.testcloudconsumermovie;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestcloudConsumerMovieApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestcloudConsumerMovieApplication.class, args);
	}
}
